﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CompanyExpenses.Pages.User
{
    public partial class Createaapplications : Page
    {
        public Createaapplications()
        {
            InitializeComponent();
            LoadExpenseTypes();
        }

        private void LoadExpenseTypes()
        {
            try
            {
                List<ExpenseType> expenseTypes = new List<ExpenseType>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT type_id, name FROM expensetypes ORDER BY name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            expenseTypes.Add(new ExpenseType
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1)
                            });
                        }
                    }
                }

                ExpenseTypeComboBox.ItemsSource = expenseTypes;
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки видов расходов: {ex.Message}");
            }
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (ExpenseTypeComboBox.SelectedItem == null)
            {
                ShowError("Выберите вид расхода");
                return;
            }

            if (string.IsNullOrEmpty(AmountTextBox.Text) || !decimal.TryParse(AmountTextBox.Text, out decimal amount))
            {
                ShowError("Введите корректную сумму");
                return;
            }

            if (amount <= 0)
            {
                ShowError("Сумма должна быть больше 0");
                return;
            }

            if (string.IsNullOrEmpty(DescriptionTextBox.Text.Trim()))
            {
                ShowError("Введите описание заявки");
                return;
            }

            int expenseTypeId = (int)ExpenseTypeComboBox.SelectedValue;
            string description = DescriptionTextBox.Text.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        INSERT INTO paymentrequests 
                        (employee_id, expense_type_id, amount_planned, description, status, created_at)
                        VALUES 
                        (@EmployeeId, @ExpenseTypeId, @Amount, @Description, 'pending', GETDATE())";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmployeeId", CurrentUser.EmployeeId);
                        command.Parameters.AddWithValue("@ExpenseTypeId", expenseTypeId);
                        command.Parameters.AddWithValue("@Amount", amount);
                        command.Parameters.AddWithValue("@Description", description);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            ShowSuccess("Заявка успешно создана и отправлена на рассмотрение!");
                            ClearForm();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка создания заявки: {ex.Message}");
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            ExpenseTypeComboBox.SelectedIndex = -1;
            AmountTextBox.Text = "";
            DescriptionTextBox.Text = "";
            HideMessages();
        }

        private void AmountTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем только цифры и запятую/точку
            Regex regex = new Regex(@"^[0-9]*(?:\.[0-9]*)?$");
            string newText = AmountTextBox.Text + e.Text;
            e.Handled = !regex.IsMatch(newText);
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
            SuccessBorder.Visibility = Visibility.Collapsed;
        }

        private void ShowSuccess(string message)
        {
            SuccessText.Text = message;
            SuccessBorder.Visibility = Visibility.Visible;
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        private void HideMessages()
        {
            ErrorBorder.Visibility = Visibility.Collapsed;
            SuccessBorder.Visibility = Visibility.Collapsed;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }
    }

    public class ExpenseType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}