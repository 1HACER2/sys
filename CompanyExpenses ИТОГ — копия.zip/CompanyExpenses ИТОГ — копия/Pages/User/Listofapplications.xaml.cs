﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace CompanyExpenses.Pages.User
{
    public partial class Listofapplications : Page
    {
        public Listofapplications()
        {
            InitializeComponent();
            LoadMyRequests();
        }

        private void LoadMyRequests()
        {
            try
            {
                List<PaymentRequest> requests = new List<PaymentRequest>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            pr.request_id,
                            pr.amount_planned,
                            pr.description,
                            pr.status,
                            pr.created_at,
                            pr.reviewed_at,
                            pr.reviewed_by,
                            pr.rejection_reason,
                            et.name as expense_type_name,
                            reviewer.first_name + ' ' + reviewer.last_name as reviewed_by_name,
                            r.final_amount,
                            r.receipt_image,
                            r.uploaded_at
                        FROM paymentrequests pr
                        INNER JOIN expensetypes et ON pr.expense_type_id = et.type_id
                        LEFT JOIN employees reviewer ON pr.reviewed_by = reviewer.employee_id
                        LEFT JOIN receipts r ON pr.request_id = r.request_id
                        WHERE pr.employee_id = @EmployeeId
                        ORDER BY pr.created_at DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmployeeId", CurrentUser.EmployeeId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                requests.Add(new PaymentRequest
                                {
                                    RequestId = reader.GetInt32(0),
                                    AmountPlanned = reader.GetDecimal(1),
                                    Description = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Status = reader.GetString(3),
                                    CreatedAt = reader.GetDateTime(4),
                                    ReviewedAt = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5),
                                    ReviewedBy = reader.IsDBNull(6) ? (int?)null : reader.GetInt32(6),
                                    RejectionReason = reader.IsDBNull(7) ? string.Empty : reader.GetString(7),
                                    ExpenseTypeName = reader.GetString(8),
                                    ReviewedByName = reader.IsDBNull(9) ? "—" : reader.GetString(9),
                                    FinalAmount = reader.IsDBNull(10) ? (decimal?)null : reader.GetDecimal(10),
                                    ReceiptImagePath = reader.IsDBNull(11) ? null : reader.GetString(11),
                                    UploadedAt = reader.IsDBNull(12) ? (DateTime?)null : reader.GetDateTime(12)
                                });
                            }
                        }
                    }
                }

                RequestsGrid.ItemsSource = requests;
                ShowStatistics(requests);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowStatistics(List<PaymentRequest> requests)
        {
            int total = requests.Count;
            int pending = requests.Count(r => r.Status == "pending");
            int approved = requests.Count(r => r.Status == "approved");
            int rejected = requests.Count(r => r.Status == "rejected");
            int completed = requests.Count(r => r.ReceiptImagePath != null);

            // Можно добавить отображение статистики в интерфейсе
            // Например, в StatusBar или отдельном TextBlock
        }

        private void UploadReceiptButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is PaymentRequest request)
            {
                if (request.Status != "approved")
                {
                    MessageBox.Show("Можно прикреплять чеки только к одобренным заявкам.", "Информация",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (!string.IsNullOrEmpty(request.ReceiptImagePath))
                {
                    MessageBox.Show("Чек уже прикреплен к этой заявке.", "Информация",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Filter = "Image files (*.jpg; *.jpeg; *.png; *.pdf)|*.jpg;*.jpeg;*.png;*.pdf|All files (*.*)|*.*",
                    Title = "Выберите файл чека"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    string filePath = openFileDialog.FileName;

                    string amountInput = ShowSimpleInputDialog(
                        "Введите фактическую сумму покупки:",
                        request.AmountPlanned.ToString("N2"));

                    if (!string.IsNullOrEmpty(amountInput) &&
                        decimal.TryParse(amountInput, out decimal finalAmount) &&
                        finalAmount > 0)
                    {
                        UploadReceipt(request.RequestId, filePath, finalAmount);
                    }
                    else if (!string.IsNullOrEmpty(amountInput))
                    {
                        MessageBox.Show("Введите корректную сумму (больше 0)", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
        }

        private string ShowSimpleInputDialog(string prompt, string defaultValue)
        {
            Window inputDialog = new Window
            {
                Title = "Ввод суммы чека",
                Width = 350,
                Height = 180,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel stackPanel = new StackPanel { Margin = new Thickness(15) };

            TextBlock promptText = new TextBlock
            {
                Text = prompt,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBlock plannedAmountText = new TextBlock
            {
                Text = $"Плановая сумма: {defaultValue} руб.",
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBox amountTextBox = new TextBox
            {
                Height = 30,
                Text = defaultValue,
                Margin = new Thickness(0, 0, 0, 15)
            };

            StackPanel buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            Button okButton = new Button
            {
                Content = "OK",
                Width = 80,
                Margin = new Thickness(0, 0, 10, 0),
                IsDefault = true
            };

            Button cancelButton = new Button
            {
                Content = "Отмена",
                Width = 80,
                IsCancel = true
            };

            string result = null;

            okButton.Click += (s, e) =>
            {
                result = amountTextBox.Text;
                inputDialog.DialogResult = true;
            };

            cancelButton.Click += (s, e) =>
            {
                inputDialog.DialogResult = false;
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            stackPanel.Children.Add(promptText);
            stackPanel.Children.Add(plannedAmountText);
            stackPanel.Children.Add(amountTextBox);
            stackPanel.Children.Add(buttonPanel);

            inputDialog.Content = stackPanel;

            amountTextBox.Focus();
            amountTextBox.SelectAll();

            if (inputDialog.ShowDialog() == true)
            {
                return result;
            }

            return null;
        }

        private void UploadReceipt(int requestId, string filePath, decimal finalAmount)
        {
            try
            {
                string fileName = $"receipt_{requestId}_{DateTime.Now:yyyyMMddHHmmss}{Path.GetExtension(filePath)}";
                string targetPath = Path.Combine("Receipts", fileName);

                string receiptsFolder = Path.Combine(Directory.GetCurrentDirectory(), "Receipts");
                if (!Directory.Exists(receiptsFolder))
                    Directory.CreateDirectory(receiptsFolder);

                string fullTargetPath = Path.Combine(receiptsFolder, fileName);
                File.Copy(filePath, fullTargetPath, true);

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM receipts WHERE request_id = @RequestId";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@RequestId", requestId);
                        int existingCount = (int)checkCommand.ExecuteScalar();

                        string query;
                        if (existingCount > 0)
                        {
                            query = @"
                                UPDATE receipts 
                                SET final_amount = @FinalAmount, 
                                    receipt_image = @ImagePath,
                                    uploaded_at = GETDATE()
                                WHERE request_id = @RequestId";
                        }
                        else
                        {
                            query = @"
                                INSERT INTO receipts (request_id, final_amount, receipt_image, uploaded_at)
                                VALUES (@RequestId, @FinalAmount, @ImagePath, GETDATE())";
                        }

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@RequestId", requestId);
                            command.Parameters.AddWithValue("@FinalAmount", finalAmount);
                            command.Parameters.AddWithValue("@ImagePath", targetPath);

                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                MessageBox.Show("Чек успешно прикреплен к заявке!", "Успех",
                                              MessageBoxButton.OK, MessageBoxImage.Information);
                                LoadMyRequests();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке чека: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadMyRequests();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        private void RequestsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Обработка изменения выделения - можно добавить логику при необходимости
        }
    }

    public class PaymentRequest
    {
        public int RequestId { get; set; }
        public string ExpenseTypeName { get; set; }
        public decimal AmountPlanned { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ReviewedAt { get; set; }
        public int? ReviewedBy { get; set; }
        public string ReviewedByName { get; set; }
        public string RejectionReason { get; set; }
        public decimal? FinalAmount { get; set; }
        public string ReceiptImagePath { get; set; }
        public DateTime? UploadedAt { get; set; }

        public string StatusDisplay
        {
            get
            {
                switch (Status)
                {
                    case "pending":
                        return "Ожидание";
                    case "approved":
                        return ReceiptImagePath != null ? "Завершено" : "Одобрено";
                    case "rejected":
                        return "Отклонено";
                    default:
                        return Status;
                }
            }
        }

        public string FinalAmountDisplay
        {
            get
            {
                return FinalAmount.HasValue ? $"{FinalAmount.Value:N2} руб." : "—";
            }
        }

        public bool CanUploadReceipt
        {
            get
            {
                return Status == "approved" && ReceiptImagePath == null;
            }
        }
    }
}