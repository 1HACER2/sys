﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages.Edit
{
    public partial class LkEdit : Page
    {
        public LkEdit()
        {
            InitializeComponent();
            LoadUserData();
        }

        private void LoadUserData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT email, first_name, last_name
                        FROM employees 
                        WHERE employee_id = @EmployeeId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmployeeId", CurrentUser.EmployeeId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                EmailTextBox.Text = reader.GetString(0);
                                FirstNameTextBox.Text = reader.GetString(1);
                                LastNameTextBox.Text = reader.GetString(2);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string firstName = FirstNameTextBox.Text.Trim();
            string lastName = LastNameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            // Валидация
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                ShowError("Заполните все обязательные поля");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query;
                    if (string.IsNullOrEmpty(password))
                    {
                        // Обновляем без пароля
                        query = @"
                            UPDATE employees 
                            SET email = @Email, first_name = @FirstName, last_name = @LastName
                            WHERE employee_id = @EmployeeId";
                    }
                    else
                    {
                        // Обновляем с паролем
                        query = @"
                            UPDATE employees 
                            SET email = @Email, first_name = @FirstName, last_name = @LastName, password = @Password
                            WHERE employee_id = @EmployeeId";
                    }

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@EmployeeId", CurrentUser.EmployeeId);

                        if (!string.IsNullOrEmpty(password))
                        {
                            command.Parameters.AddWithValue("@Password", password);
                        }

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Данные успешно обновлены!", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);

                            // Обновляем CurrentUser
                            CurrentUser.FirstName = firstName;
                            CurrentUser.LastName = lastName;

                            Manager.MainFrame.Navigate(new Lk());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка сохранения: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Lk());
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }
    }
}