﻿using CompanyExpenses.Pages.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace CompanyExpenses.Pages.Edit
{
    public partial class TypesofexpensesPageEdit : Page
    {
        private List<ExpenseTypeInfo> _expenseTypes;
        private ICollectionView _expenseTypesView;

        public TypesofexpensesPageEdit()
        {
            InitializeComponent();
            Loaded += TypesofexpensesPageEdit_Loaded;
        }

        private void TypesofexpensesPageEdit_Loaded(object sender, RoutedEventArgs e)
        {
            LoadExpenseTypes();
        }

        private void LoadExpenseTypes()
        {
            try
            {
                _expenseTypes = new List<ExpenseTypeInfo>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            type_id,
                            name
                        FROM expensetypes 
                        ORDER BY name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _expenseTypes.Add(new ExpenseTypeInfo
                            {
                                TypeId = reader.GetInt32(0),
                                Name = reader.GetString(1)
                            });
                        }
                    }
                }

                // Создаем CollectionView для поддержки фильтрации
                _expenseTypesView = CollectionViewSource.GetDefaultView(_expenseTypes);
                _expenseTypesView.Filter = ExpenseTypeFilter;

                // Привязываем DataGrid к CollectionView
                ExpenseTypesGrid.ItemsSource = _expenseTypesView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Метод-фильтр для поиска
        private bool ExpenseTypeFilter(object item)
        {
            if (string.IsNullOrWhiteSpace(SearchTextBox?.Text))
                return true;

            if (item is ExpenseTypeInfo expenseType)
            {
                string searchText = SearchTextBox.Text.ToLower();

                // Ищем по названию вида расхода
                return expenseType.Name.ToLower().Contains(searchText);
            }

            return false;
        }

        // Обработчик изменения текста поиска
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Обновляем фильтр при каждом изменении текста
            _expenseTypesView?.Refresh();
        }

        // Обработчик кнопки очистки поиска
        private void ClearSearchButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = string.Empty;
            _expenseTypesView?.Refresh();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string newExpenseTypeName = NewExpenseTypeTextBox.Text.Trim();

            if (string.IsNullOrEmpty(newExpenseTypeName))
            {
                MessageBox.Show("Введите название вида расхода", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO expensetypes (name) VALUES (@Name)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", newExpenseTypeName);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Вид расхода успешно добавлен", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            NewExpenseTypeTextBox.Clear();
                            LoadExpenseTypes();
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627) // Ошибка уникальности
                {
                    MessageBox.Show("Вид расхода с таким названием уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Ошибка добавления вида расхода: {sqlEx.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления вида расхода: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is ExpenseTypeInfo expenseType)
            {
                // Принудительно обновляем все изменения
                ExpenseTypesGrid.CommitEdit(DataGridEditingUnit.Row, true);

                SaveExpenseTypeChanges(expenseType);
            }
        }

        private void SaveExpenseTypeChanges(ExpenseTypeInfo expenseType)
        {
            if (string.IsNullOrWhiteSpace(expenseType.Name))
            {
                MessageBox.Show("Название вида расхода не может быть пустым", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                LoadExpenseTypes(); // Перезагружаем чтобы восстановить оригинальные значения
                return;
            }

            string newName = expenseType.Name.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    // Сначала получаем текущие данные из БД для проверки
                    string checkQuery = "SELECT name FROM expensetypes WHERE type_id = @TypeId";
                    string oldName = "";

                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@TypeId", expenseType.TypeId);
                        oldName = (string)checkCommand.ExecuteScalar();
                    }

                    // Проверяем, изменилось ли название
                    if (oldName == newName)
                    {
                        MessageBox.Show("Название не изменилось", "Информация",
                                      MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    string updateQuery = "UPDATE expensetypes SET name = @Name WHERE type_id = @TypeId";

                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Name", newName);
                        command.Parameters.AddWithValue("@TypeId", expenseType.TypeId);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Вид расхода успешно обновлен", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            LoadExpenseTypes(); // Полная перезагрузка для обновления отображения
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627)
                {
                    MessageBox.Show("Вид расхода с таким названием уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Ошибка обновления: {sqlEx.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
                LoadExpenseTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                LoadExpenseTypes();
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is ExpenseTypeInfo expenseType)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить вид расхода \"{expenseType.Name}\"?",
                                           "Подтверждение удаления",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                        {
                            connection.Open();

                            // Проверяем, есть ли заявки с этим видом расхода
                            string checkQuery = "SELECT COUNT(*) FROM paymentrequests WHERE expense_type_id = @TypeId";
                            using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                            {
                                checkCommand.Parameters.AddWithValue("@TypeId", expenseType.TypeId);
                                int requestsCount = (int)checkCommand.ExecuteScalar();

                                if (requestsCount > 0)
                                {
                                    MessageBox.Show($"Невозможно удалить вид расхода. Есть заявки с этим видом расхода ({requestsCount} шт.).", "Ошибка",
                                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }
                            }

                            string deleteQuery = "DELETE FROM expensetypes WHERE type_id = @TypeId";
                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@TypeId", expenseType.TypeId);

                                int deleteResult = command.ExecuteNonQuery();

                                if (deleteResult > 0)
                                {
                                    MessageBox.Show("Вид расхода успешно удален", "Успех",
                                                  MessageBoxButton.OK, MessageBoxImage.Information);
                                    LoadExpenseTypes();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadExpenseTypes();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        private void ExpenseTypesGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var textBox = e.EditingElement as TextBox;
                if (textBox != null)
                {
                    // Принудительно обновляем привязку
                    var binding = textBox.GetBindingExpression(TextBox.TextProperty);
                    binding?.UpdateSource();
                }
            }
        }

        private void ExpenseTypesGrid_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ExpenseTypesGrid.CommitEdit(DataGridEditingUnit.Row, true);
                e.Handled = true;
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TypesofexpensesPage());
        }
    }

    public class ExpenseTypeInfo : INotifyPropertyChanged
    {
        private string _name;

        public int TypeId { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}