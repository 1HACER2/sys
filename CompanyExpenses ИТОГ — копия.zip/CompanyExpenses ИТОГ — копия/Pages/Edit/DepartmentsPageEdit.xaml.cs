﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CompanyExpenses.Pages.Edit
{
    public partial class DepartmentsPageEdit : Page
    {
        private List<Department> _departments;
        private List<Department> _filteredDepartments;

        public DepartmentsPageEdit()
        {
            InitializeComponent();
            LoadDepartments();
        }

        private void LoadDepartments()
        {
            try
            {
                _departments = new List<Department>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT department_id, name FROM departments ORDER BY department_id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _departments.Add(new Department
                            {
                                DepartmentId = reader.GetInt32(0),
                                DepartmentName = reader.GetString(1)
                            });
                        }
                    }
                }

                // Инициализируем отфильтрованный список
                _filteredDepartments = new List<Department>(_departments);
                DepartmentsGrid.ItemsSource = null;
                DepartmentsGrid.ItemsSource = _filteredDepartments;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Метод для фильтрации
        private void FilterDepartments()
        {
            if (string.IsNullOrWhiteSpace(SearchTextBox?.Text))
            {
                _filteredDepartments = new List<Department>(_departments);
            }
            else
            {
                string searchText = SearchTextBox.Text.ToLower();
                _filteredDepartments = _departments
                    .Where(d => d.DepartmentName.ToLower().Contains(searchText) ||
                                d.DepartmentId.ToString().Contains(searchText))
                    .ToList();
            }

            DepartmentsGrid.ItemsSource = null;
            DepartmentsGrid.ItemsSource = _filteredDepartments;
        }

        // Обработчик изменения текста поиска
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterDepartments();
        }

        // Обработчик кнопки очистки поиска
        private void ClearSearchButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = string.Empty;
            FilterDepartments();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string newDepartmentName = NewDepartmentTextBox.Text.Trim();

            if (string.IsNullOrEmpty(newDepartmentName))
            {
                MessageBox.Show("Введите название отдела", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO departments (name) VALUES (@Name)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", newDepartmentName);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Отдел успешно добавлен", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            NewDepartmentTextBox.Clear();
                            LoadDepartments();
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627) // Ошибка уникальности
                {
                    MessageBox.Show("Отдел с таким названием уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Ошибка добавления отдела: {sqlEx.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления отдела: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is Department department)
            {
                // Принудительно обновляем привязку
                DepartmentsGrid.CommitEdit(DataGridEditingUnit.Row, true);

                if (string.IsNullOrWhiteSpace(department.DepartmentName))
                {
                    MessageBox.Show("Название отдела не может быть пустым", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    LoadDepartments(); // Перезагружаем чтобы восстановить оригинальное значение
                    return;
                }

                string newName = department.DepartmentName.Trim();

                try
                {
                    using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                    {
                        connection.Open();

                        // Проверяем, изменилось ли название
                        string checkQuery = "SELECT name FROM departments WHERE department_id = @DepartmentId";
                        string oldName = "";

                        using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                        {
                            checkCommand.Parameters.AddWithValue("@DepartmentId", department.DepartmentId);
                            oldName = (string)checkCommand.ExecuteScalar();
                        }

                        if (oldName == newName)
                        {
                            MessageBox.Show("Название не изменилось", "Информация",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }

                        string updateQuery = "UPDATE departments SET name = @Name WHERE department_id = @DepartmentId";

                        using (SqlCommand command = new SqlCommand(updateQuery, connection))
                        {
                            command.Parameters.AddWithValue("@Name", newName);
                            command.Parameters.AddWithValue("@DepartmentId", department.DepartmentId);

                            int result = command.ExecuteNonQuery();

                            if (result > 0)
                            {
                                MessageBox.Show("Отдел успешно обновлен", "Успех",
                                              MessageBoxButton.OK, MessageBoxImage.Information);
                                // Не перезагружаем полностью, только обновляем текущие данные
                                RefreshCurrentData();
                            }
                            else
                            {
                                MessageBox.Show("Не удалось обновить отдел", "Ошибка",
                                              MessageBoxButton.OK, MessageBoxImage.Warning);
                                LoadDepartments(); // Перезагружаем данные
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Number == 2627) // Ошибка уникальности
                    {
                        MessageBox.Show("Отдел с таким названием уже существует", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        MessageBox.Show($"Ошибка обновления отдела: {sqlEx.Message}", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    LoadDepartments(); // Перезагружаем данные при ошибке
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обновления отдела: {ex.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                    LoadDepartments(); // Перезагружаем данные при ошибке
                }
            }
        }

        private void RefreshCurrentData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT department_id, name FROM departments ORDER BY department_id";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        _departments.Clear();
                        while (reader.Read())
                        {
                            _departments.Add(new Department
                            {
                                DepartmentId = reader.GetInt32(0),
                                DepartmentName = reader.GetString(1)
                            });
                        }
                    }
                }

                // Обновляем фильтр
                FilterDepartments();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is Department department)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить отдел \"{department.DepartmentName}\"?",
                                           "Подтверждение удаления",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                        {
                            connection.Open();

                            // Проверяем, есть ли сотрудники в этом отделе
                            string checkQuery = "SELECT COUNT(*) FROM employees WHERE department_id = @DepartmentId";
                            using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                            {
                                checkCommand.Parameters.AddWithValue("@DepartmentId", department.DepartmentId);
                                int employeeCount = (int)checkCommand.ExecuteScalar();

                                if (employeeCount > 0)
                                {
                                    MessageBox.Show($"Невозможно удалить отдел. В отделе есть сотрудники ({employeeCount} чел.).", "Ошибка",
                                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }
                            }

                            // Проверяем, есть ли лимиты для этого отдела
                            string checkLimitsQuery = "SELECT COUNT(*) FROM spendinglimits WHERE department_id = @DepartmentId";
                            using (SqlCommand checkCommand = new SqlCommand(checkLimitsQuery, connection))
                            {
                                checkCommand.Parameters.AddWithValue("@DepartmentId", department.DepartmentId);
                                int limitsCount = (int)checkCommand.ExecuteScalar();

                                if (limitsCount > 0)
                                {
                                    MessageBox.Show($"Невозможно удалить отдел. Для отдела установлены лимиты расходов.", "Ошибка",
                                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }
                            }

                            string deleteQuery = "DELETE FROM departments WHERE department_id = @DepartmentId";
                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@DepartmentId", department.DepartmentId);

                                int deleteResult = command.ExecuteNonQuery();

                                if (deleteResult > 0)
                                {
                                    MessageBox.Show("Отдел успешно удален", "Успех",
                                                  MessageBoxButton.OK, MessageBoxImage.Information);
                                    LoadDepartments();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка удаления отдела: {ex.Message}", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadDepartments();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        private void DepartmentsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Можно добавить дополнительную логику при выборе строки
        }

        // Обработчик завершения редактирования ячейки
        private void DepartmentsGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var textBox = e.EditingElement as TextBox;
                if (textBox != null)
                {
                    // Принудительно обновляем привязку
                    var binding = textBox.GetBindingExpression(TextBox.TextProperty);
                    binding?.UpdateSource();
                }
            }
        }

        // Обработчик события для завершения редактирования по нажатию Enter
        private void DepartmentsGrid_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                DepartmentsGrid.CommitEdit(DataGridEditingUnit.Row, true);
                e.Handled = true;
            }
        }
    }

    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    }
}