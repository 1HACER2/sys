﻿using CompanyExpenses.Pages.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace CompanyExpenses.Pages.Edit
{
    public partial class EmployeePageEdit : Page, INotifyPropertyChanged
    {
        private List<EmployeeInfo> _employees;
        private List<DepartmentInfo> _departments;
        private List<RoleInfo> _roles;
        private ICollectionView _employeesView;

        public List<DepartmentInfo> Departments => _departments;
        public List<RoleInfo> Roles => _roles;

        public event PropertyChangedEventHandler PropertyChanged;

        public EmployeePageEdit()
        {
            InitializeComponent();
            Loaded += EmployeePageEdit_Loaded;
        }

        private void EmployeePageEdit_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void LoadData()
        {
            try
            {
                LoadDepartments();
                LoadRoles();
                LoadEmployees();

                // Устанавливаем DataContext для привязки в XAML
                DataContext = this;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadDepartments()
        {
            _departments = new List<DepartmentInfo>();

            using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
            {
                connection.Open();

                string query = "SELECT department_id, name FROM departments ORDER BY name";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        _departments.Add(new DepartmentInfo
                        {
                            DepartmentId = reader.GetInt32(0),
                            DepartmentName = reader.GetString(1)
                        });
                    }
                }
            }

            NewDepartmentComboBox.ItemsSource = _departments;
            if (_departments.Count > 0)
                NewDepartmentComboBox.SelectedIndex = 0;

            OnPropertyChanged(nameof(Departments));
        }

        private void LoadRoles()
        {
            _roles = new List<RoleInfo>();

            using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
            {
                connection.Open();

                string query = "SELECT ID_Role, Name_Role FROM role ORDER BY ID_Role";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        _roles.Add(new RoleInfo
                        {
                            RoleId = reader.GetInt32(0),
                            RoleName = reader.GetString(1).Trim()
                        });
                    }
                }
            }

            NewRoleComboBox.ItemsSource = _roles;
            if (_roles.Count > 0)
                NewRoleComboBox.SelectedIndex = 0;

            OnPropertyChanged(nameof(Roles));
        }

        private void LoadEmployees()
        {
            _employees = new List<EmployeeInfo>();

            using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
            {
                connection.Open();

                string query = @"
                    SELECT 
                        e.employee_id,
                        e.first_name,
                        e.last_name,
                        e.email,
                        e.department_id,
                        e.ID_Role,
                        d.name as department_name,
                        r.Name_Role as role_name
                    FROM employees e
                    LEFT JOIN departments d ON e.department_id = d.department_id
                    LEFT JOIN role r ON e.ID_Role = r.ID_Role
                    ORDER BY e.last_name, e.first_name";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        _employees.Add(new EmployeeInfo
                        {
                            EmployeeId = reader.GetInt32(0),
                            FirstName = reader.GetString(1),
                            LastName = reader.GetString(2),
                            Email = reader.GetString(3),
                            DepartmentId = reader.GetInt32(4),
                            RoleId = reader.GetInt32(5),
                            DepartmentName = reader.IsDBNull(6) ? "Не указан" : reader.GetString(6),
                            RoleName = reader.IsDBNull(7) ? "Не указана" : reader.GetString(7).Trim()
                        });
                    }
                }
            }

            // Создаем CollectionView для поддержки фильтрации
            _employeesView = CollectionViewSource.GetDefaultView(_employees);
            _employeesView.Filter = EmployeeFilter;

            // Привязываем DataGrid к CollectionView, а не напрямую к списку
            EmployeesGrid.ItemsSource = _employeesView;
        }

        // Метод-фильтр для поиска
        private bool EmployeeFilter(object item)
        {
            if (string.IsNullOrWhiteSpace(SearchTextBox?.Text))
                return true;

            if (item is EmployeeInfo employee)
            {
                string searchText = SearchTextBox.Text.ToLower();

                // Ищем по ФИО, email и названию отдела
                return employee.LastName.ToLower().Contains(searchText) ||
                       employee.FirstName.ToLower().Contains(searchText) ||
                       employee.Email.ToLower().Contains(searchText) ||
                       (employee.DepartmentName?.ToLower().Contains(searchText) ?? false);
            }

            return false;
        }

        // Обработчик изменения текста поиска
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Обновляем фильтр при каждом изменении текста
            _employeesView?.Refresh();
        }

        // Обработчик кнопки очистки поиска
        private void ClearSearchButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = string.Empty;
            _employeesView?.Refresh();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string firstName = NewFirstNameTextBox.Text.Trim();
            string lastName = NewLastNameTextBox.Text.Trim();
            string email = NewEmailTextBox.Text.Trim();
            string password = NewPasswordTextBox.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (NewDepartmentComboBox.SelectedValue == null || NewRoleComboBox.SelectedValue == null)
            {
                MessageBox.Show("Выберите отдел и роль", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int departmentId = (int)NewDepartmentComboBox.SelectedValue;
            int roleId = (int)NewRoleComboBox.SelectedValue;

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        INSERT INTO employees (first_name, last_name, email, password, department_id, ID_Role)
                        VALUES (@FirstName, @LastName, @Email, @Password, @DepartmentId, @RoleId)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@DepartmentId", departmentId);
                        command.Parameters.AddWithValue("@RoleId", roleId);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Сотрудник успешно добавлен", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            ClearAddForm();
                            LoadEmployees();
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627) // Ошибка уникальности
                {
                    MessageBox.Show("Сотрудник с таким email уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Ошибка добавления сотрудника: {sqlEx.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления сотрудника: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is EmployeeInfo employee)
            {
                // Принудительно обновляем все изменения
                EmployeesGrid.CommitEdit(DataGridEditingUnit.Row, true);

                SaveEmployeeChanges(employee);
            }
        }

        private void SaveEmployeeChanges(EmployeeInfo employee)
        {
            if (string.IsNullOrWhiteSpace(employee.FirstName) || string.IsNullOrWhiteSpace(employee.LastName) ||
                string.IsNullOrWhiteSpace(employee.Email))
            {
                MessageBox.Show("Заполните все обязательные поля", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                LoadEmployees(); // Перезагружаем чтобы восстановить оригинальные значения
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    // Сначала получаем текущие данные из БД для проверки
                    string checkQuery = "SELECT first_name, last_name, email, department_id, ID_Role FROM employees WHERE employee_id = @EmployeeId";
                    string oldFirstName = "", oldLastName = "", oldEmail = "";
                    int oldDepartmentId = 0, oldRoleId = 0;

                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                        using (var reader = checkCommand.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                oldFirstName = reader.GetString(0);
                                oldLastName = reader.GetString(1);
                                oldEmail = reader.GetString(2);
                                oldDepartmentId = reader.GetInt32(3);
                                oldRoleId = reader.GetInt32(4);
                            }
                        }
                    }

                    // Проверяем, изменились ли данные
                    if (oldFirstName == employee.FirstName.Trim() &&
                        oldLastName == employee.LastName.Trim() &&
                        oldEmail == employee.Email.Trim() &&
                        oldDepartmentId == employee.DepartmentId &&
                        oldRoleId == employee.RoleId)
                    {
                        MessageBox.Show("Данные не изменились", "Информация",
                                      MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    string updateQuery = @"
                        UPDATE employees 
                        SET first_name = @FirstName, 
                            last_name = @LastName, 
                            email = @Email,
                            department_id = @DepartmentId,
                            ID_Role = @RoleId
                        WHERE employee_id = @EmployeeId";

                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", employee.FirstName.Trim());
                        command.Parameters.AddWithValue("@LastName", employee.LastName.Trim());
                        command.Parameters.AddWithValue("@Email", employee.Email.Trim());
                        command.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);
                        command.Parameters.AddWithValue("@RoleId", employee.RoleId);
                        command.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Данные сотрудника обновлены", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            LoadEmployees(); // Полная перезагрузка для обновления отображения
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 2627)
                {
                    MessageBox.Show("Сотрудник с таким email уже существует", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Ошибка обновления: {sqlEx.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
                LoadEmployees();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                LoadEmployees();
            }
        }

        // Обработчики изменений в ComboBox
        private void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.DataContext is EmployeeInfo employee)
            {
                if (comboBox.SelectedValue != null)
                {
                    employee.DepartmentId = (int)comboBox.SelectedValue;
                }
            }
        }

        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.DataContext is EmployeeInfo employee)
            {
                if (comboBox.SelectedValue != null)
                {
                    employee.RoleId = (int)comboBox.SelectedValue;
                }
            }
        }

        // Обработчик завершения редактирования ячейки
        private void EmployeesGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var textBox = e.EditingElement as TextBox;
                if (textBox != null)
                {
                    // Принудительно обновляем привязку
                    var binding = textBox.GetBindingExpression(TextBox.TextProperty);
                    binding?.UpdateSource();
                }
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is EmployeeInfo employee)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить сотрудника {employee.LastName} {employee.FirstName}?",
                                           "Подтверждение удаления",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                        {
                            connection.Open();

                            // Проверяем, есть ли заявки у сотрудника
                            string checkQuery = "SELECT COUNT(*) FROM paymentrequests WHERE employee_id = @EmployeeId";
                            using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                            {
                                checkCommand.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                                int requestsCount = (int)checkCommand.ExecuteScalar();

                                if (requestsCount > 0)
                                {
                                    MessageBox.Show($"Невозможно удалить сотрудника. У сотрудника есть заявки ({requestsCount} шт.).", "Ошибка",
                                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }
                            }

                            string deleteQuery = "DELETE FROM employees WHERE employee_id = @EmployeeId";
                            using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                            {
                                command.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);

                                int deleteResult = command.ExecuteNonQuery();

                                if (deleteResult > 0)
                                {
                                    MessageBox.Show("Сотрудник успешно удален", "Успех",
                                                  MessageBoxButton.OK, MessageBoxImage.Information);
                                    LoadEmployees();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void ClearAddForm()
        {
            NewFirstNameTextBox.Clear();
            NewLastNameTextBox.Clear();
            NewEmailTextBox.Clear();
            NewPasswordTextBox.Clear();
            if (NewDepartmentComboBox.Items.Count > 0)
                NewDepartmentComboBox.SelectedIndex = 0;
            if (NewRoleComboBox.Items.Count > 0)
                NewRoleComboBox.SelectedIndex = 0;
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        private void EmployeesGrid_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                EmployeesGrid.CommitEdit(DataGridEditingUnit.Row, true);
                e.Handled = true;
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new EmployeePage());
        }
    }

    public class EmployeeInfo : INotifyPropertyChanged
    {
        private string _firstName;
        private string _lastName;
        private string _email;
        private int _departmentId;
        private int _roleId;

        public int EmployeeId { get; set; }

        public string FirstName
        {
            get => _firstName;
            set
            {
                _firstName = value;
                OnPropertyChanged(nameof(FirstName));
            }
        }

        public string LastName
        {
            get => _lastName;
            set
            {
                _lastName = value;
                OnPropertyChanged(nameof(LastName));
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }

        public int DepartmentId
        {
            get => _departmentId;
            set
            {
                _departmentId = value;
                OnPropertyChanged(nameof(DepartmentId));
            }
        }

        public int RoleId
        {
            get => _roleId;
            set
            {
                _roleId = value;
                OnPropertyChanged(nameof(RoleId));
            }
        }

        public string DepartmentName { get; set; }
        public string RoleName { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class DepartmentInfo
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    }

    public class RoleInfo
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}