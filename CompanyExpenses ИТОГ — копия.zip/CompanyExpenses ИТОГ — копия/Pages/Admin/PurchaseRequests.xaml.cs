﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages.Admin
{
    public partial class PurchaseRequests : Page
    {
        private bool showOnlyPending = false;

        public PurchaseRequests()
        {
            InitializeComponent();
            LoadRequests();
        }

        private void LoadRequests()
        {
            try
            {
                List<PaymentRequest> requests = new List<PaymentRequest>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            pr.request_id,
                            pr.amount_planned,
                            pr.description,
                            pr.status,
                            pr.created_at,
                            pr.reviewed_at,
                            pr.reviewed_by,
                            pr.rejection_reason,
                            e.first_name + ' ' + e.last_name as employee_name,
                            et.name as expense_type_name,
                            reviewer.first_name + ' ' + reviewer.last_name as reviewed_by_name
                        FROM paymentrequests pr
                        INNER JOIN employees e ON pr.employee_id = e.employee_id
                        INNER JOIN expensetypes et ON pr.expense_type_id = et.type_id
                        LEFT JOIN employees reviewer ON pr.reviewed_by = reviewer.employee_id
                        WHERE (@ShowOnlyPending = 0 OR pr.status = 'pending')
                        ORDER BY pr.created_at DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ShowOnlyPending", showOnlyPending);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                requests.Add(new PaymentRequest
                                {
                                    RequestId = reader.GetInt32(0),
                                    AmountPlanned = reader.GetDecimal(1),
                                    Description = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Status = reader.GetString(3),
                                    CreatedAt = reader.GetDateTime(4),
                                    ReviewedAt = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5),
                                    ReviewedBy = reader.IsDBNull(6) ? (int?)null : reader.GetInt32(6),
                                    RejectionReason = reader.IsDBNull(7) ? string.Empty : reader.GetString(7),
                                    EmployeeName = reader.GetString(8),
                                    ExpenseTypeName = reader.GetString(9),
                                    ReviewedByName = reader.IsDBNull(10) ? "—" : reader.GetString(10)
                                });
                            }
                        }
                    }
                }

                RequestsGrid.ItemsSource = requests;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Обработчик для кнопки "Одобрить" в строке таблицы
        private void ApproveRowButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is PaymentRequest request)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите одобрить заявку от {request.EmployeeName}?",
                                           "Подтверждение одобрения",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    UpdateRequestStatus(request.RequestId, "approved", null, "Заявка одобрена");
                }
            }
        }

        // Обработчик для кнопки "Отклонить" в строке таблицы
        private void RejectRowButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is PaymentRequest request)
            {
                // Создаем диалог для ввода причины отклонения
                string reason = ShowInputDialog("Введите причину отклонения заявки:");

                if (!string.IsNullOrEmpty(reason))
                {
                    var result = MessageBox.Show($"Вы уверены, что хотите отклонить заявку от {request.EmployeeName}?\nПричина: {reason}",
                                               "Подтверждение отклонения",
                                               MessageBoxButton.YesNo,
                                               MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        UpdateRequestStatus(request.RequestId, "rejected", reason, "Заявка отклонена");
                    }
                }
                else
                {
                    MessageBox.Show("Необходимо указать причину отклонения.", "Внимание",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private string ShowInputDialog(string prompt)
        {
            Window dialog = new Window
            {
                Title = "Причина отклонения",
                Width = 400,
                Height = 200,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel stackPanel = new StackPanel { Margin = new Thickness(10) };

            TextBlock textBlock = new TextBlock
            {
                Text = prompt,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 10)
            };

            TextBox textBox = new TextBox
            {
                Height = 80,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                AcceptsReturn = true
            };

            StackPanel buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 0, 0)
            };

            Button okButton = new Button
            {
                Content = "OK",
                Width = 80,
                Margin = new Thickness(0, 0, 10, 0),
                IsDefault = true
            };

            Button cancelButton = new Button
            {
                Content = "Отмена",
                Width = 80,
                IsCancel = true
            };

            string result = null;

            okButton.Click += (s, e) =>
            {
                result = textBox.Text;
                dialog.DialogResult = true;
            };

            cancelButton.Click += (s, e) =>
            {
                dialog.DialogResult = false;
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            stackPanel.Children.Add(textBlock);
            stackPanel.Children.Add(textBox);
            stackPanel.Children.Add(buttonPanel);

            dialog.Content = stackPanel;

            // Устанавливаем фокус на текстовое поле
            textBox.Focus();

            if (dialog.ShowDialog() == true)
            {
                return result;
            }

            return null;
        }

        private void UpdateRequestStatus(int requestId, string status, string rejectionReason, string message)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        UPDATE paymentrequests 
                        SET status = @Status, 
                            reviewed_at = GETDATE(),
                            reviewed_by = @ReviewedBy,
                            rejection_reason = @RejectionReason
                        WHERE request_id = @RequestId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Status", status);
                        command.Parameters.AddWithValue("@ReviewedBy", CurrentUser.EmployeeId);
                        command.Parameters.AddWithValue("@RequestId", requestId);
                        command.Parameters.AddWithValue("@RejectionReason",
                            string.IsNullOrEmpty(rejectionReason) ? (object)DBNull.Value : rejectionReason);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show(message, "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            LoadRequests();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления статуса: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadRequests();
        }

        private void PendingOnlyButton_Click(object sender, RoutedEventArgs e)
        {
            showOnlyPending = !showOnlyPending;
            PendingOnlyButton.Content = showOnlyPending ? "📋 Все заявки" : "📋 Только ожидающие";
            LoadRequests();
        }

        private void RequestsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Теперь выбор строки не нужен для действий, но оставим на случай если понадобится
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }

        // Удаляем старые обработчики, которые больше не используются
        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            // Этот метод больше не используется, так как кнопки теперь в таблице
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            // Этот метод больше не используется, так как кнопки теперь в таблице
        }
    }

    public class PaymentRequest
    {
        public int RequestId { get; set; }
        public string EmployeeName { get; set; }
        public string ExpenseTypeName { get; set; }
        public decimal AmountPlanned { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ReviewedAt { get; set; }
        public int? ReviewedBy { get; set; }
        public string ReviewedByName { get; set; }
        public string RejectionReason { get; set; }

        // Свойство для отображения статуса на русском
        public string StatusDisplay
        {
            get
            {
                switch (Status)
                {
                    case "pending":
                        return "Ожидание";
                    case "approved":
                        return "Одобрено";
                    case "rejected":
                        return "Отклонено";
                    default:
                        return Status;
                }
            }
        }
    }
}