﻿using CompanyExpenses.Pages.Edit;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages.Admin
{
    public partial class DepartmentsPage : Page
    {
        public DepartmentsPage()
        {
            InitializeComponent();
            LoadDepartments();
        }

        private void LoadDepartments()
        {
            try
            {
                List<Department> departments = new List<Department>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT name FROM departments ORDER BY name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            departments.Add(new Department
                            {
                                DepartmentName = reader.GetString(0)
                            });
                        }
                    }
                }

                DepartmentsGrid.ItemsSource = departments;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadDepartments();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new DepartmentsPageEdit());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }
    }

    public class Department
    {
        public string DepartmentName { get; set; }
    }
}