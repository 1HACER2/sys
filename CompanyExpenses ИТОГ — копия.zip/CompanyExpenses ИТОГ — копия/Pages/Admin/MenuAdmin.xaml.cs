﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages.Admin
{
    public partial class MenuAdmin : Page
    {
        public MenuAdmin()
        {
            InitializeComponent();
            LoadExtendedStatistics(); // Теперь будет вызываться правильный метод
        }

        private void LoadExtendedStatistics()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    // 1. Общее количество чеков
                    string receiptsQuery = "SELECT COUNT(*) FROM receipts";
                    using (SqlCommand receiptsCommand = new SqlCommand(receiptsQuery, connection))
                    {
                        int totalReceipts = (int)receiptsCommand.ExecuteScalar();
                        TotalReceiptsCount.Text = totalReceipts.ToString();
                    }

                    // 2. Количество сотрудников
                    string employeesQuery = "SELECT COUNT(*) FROM employees";
                    using (SqlCommand employeesCommand = new SqlCommand(employeesQuery, connection))
                    {
                        int employeesCount = (int)employeesCommand.ExecuteScalar();
                        EmployeesCount.Text = employeesCount.ToString();
                    }

                    // 3. Общая сумма расходов из одобренных заявок с чеками
                    string expensesQuery = @"
                        SELECT ISNULL(SUM(r.final_amount), 0) 
                        FROM receipts r
                        INNER JOIN paymentrequests pr ON r.request_id = pr.request_id
                        WHERE pr.status = 'approved'";
                    using (SqlCommand expensesCommand = new SqlCommand(expensesQuery, connection))
                    {
                        decimal totalExpenses = (decimal)expensesCommand.ExecuteScalar();
                        TotalExpenses.Text = $"{totalExpenses:N2} руб.";
                    }

                    // 4. Количество ожидающих заявок
                    string pendingQuery = "SELECT COUNT(*) FROM paymentrequests WHERE status = 'pending'";
                    using (SqlCommand pendingCommand = new SqlCommand(pendingQuery, connection))
                    {
                        int pendingCount = (int)pendingCommand.ExecuteScalar();
                        PendingRequestsCount.Text = pendingCount.ToString();
                    }

                    // 5. Средняя сумма чека
                    string avgReceiptQuery = "SELECT ISNULL(AVG(final_amount), 0) FROM receipts";
                    using (SqlCommand avgReceiptCommand = new SqlCommand(avgReceiptQuery, connection))
                    {
                        decimal avgReceipt = (decimal)avgReceiptCommand.ExecuteScalar();
                        AverageReceipt.Text = $"{avgReceipt:N2} руб.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки статистики: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);

                // Устанавливаем значения по умолчанию при ошибке
                TotalReceiptsCount.Text = "0";
                EmployeesCount.Text = "0";
                TotalExpenses.Text = "0 руб.";
                PendingRequestsCount.Text = "0";
                AverageReceipt.Text = "0 руб.";
            }
        }

        // Удалите этот лишний метод
        // private void LoadAdditionalStatistics(SqlConnection connection)
        // {
        //     // Этот метод больше не нужен, так как вся статистика загружается в основном методе
        // }

        private void PurchaseRequests_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PurchaseRequests());
        }

        private void Receipts_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Listofreceipts());
        }

        private void Editreferencebooks_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Referencebooks());
        }

        private void Lk_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Lk());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AuthorizationPage());
        }
        private void SpendingLimits_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new SpendingLimitsPage());
        }
    }
}