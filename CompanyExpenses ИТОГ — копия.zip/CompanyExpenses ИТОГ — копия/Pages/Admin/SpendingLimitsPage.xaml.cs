﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;

namespace CompanyExpenses.Pages.Admin
{
    public partial class SpendingLimitsPage : Page
    {
        private List<DepartmentLimit> _departmentLimits;

        public SpendingLimitsPage()
        {
            InitializeComponent();
            LoadDepartmentLimits();
        }

        private void LoadDepartmentLimits()
        {
            try
            {
                _departmentLimits = new List<DepartmentLimit>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            d.department_id,
                            d.name as department_name,
                            COALESCE(sl.limit_amount, 0) as current_limit
                        FROM departments d
                        LEFT JOIN spendinglimits sl ON d.department_id = sl.department_id
                        ORDER BY d.name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _departmentLimits.Add(new DepartmentLimit
                            {
                                DepartmentId = reader.GetInt32(0),
                                DepartmentName = reader.GetString(1),
                                CurrentLimit = reader.GetDecimal(2),
                                NewLimit = reader.GetDecimal(2) // Изначально равен текущему лимиту
                            });
                        }
                    }
                }

                // Создаем новую коллекцию вместо обновления существующей
                var newCollection = new List<DepartmentLimit>(_departmentLimits);
                LimitsDataGrid.ItemsSource = newCollection;
                _departmentLimits = newCollection;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки лимитов: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveAllButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Отменяем редактирование вместо CommitEdit
                LimitsDataGrid.CancelEdit();

                int updatedCount = 0;
                bool hasErrors = false;
                string errorMessage = "";

                // Проверяем все значения перед сохранением
                foreach (var departmentLimit in _departmentLimits)
                {
                    if (departmentLimit.NewLimit < 0)
                    {
                        errorMessage = $"Лимит для отдела '{departmentLimit.DepartmentName}' не может быть отрицательным";
                        hasErrors = true;
                        break;
                    }
                }

                if (hasErrors)
                {
                    MessageBox.Show(errorMessage, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    foreach (var departmentLimit in _departmentLimits)
                    {
                        // Проверяем, изменился ли лимит (с учетом точности decimal)
                        if (Math.Abs(departmentLimit.NewLimit - departmentLimit.CurrentLimit) > 0.001m)
                        {
                            // Используем MERGE для обновления или вставки
                            string mergeQuery = @"
                                MERGE spendinglimits AS target
                                USING (VALUES (@DepartmentId, @LimitAmount)) AS source (department_id, limit_amount)
                                ON target.department_id = source.department_id
                                WHEN MATCHED THEN
                                    UPDATE SET limit_amount = source.limit_amount
                                WHEN NOT MATCHED THEN
                                    INSERT (department_id, limit_amount)
                                    VALUES (source.department_id, source.limit_amount);";

                            using (SqlCommand command = new SqlCommand(mergeQuery, connection))
                            {
                                command.Parameters.AddWithValue("@DepartmentId", departmentLimit.DepartmentId);
                                command.Parameters.AddWithValue("@LimitAmount", departmentLimit.NewLimit);

                                int result = command.ExecuteNonQuery();

                                if (result >= 0) // MERGE возвращает количество затронутых строк
                                {
                                    updatedCount++;
                                    // Обновляем текущий лимит в объекте
                                    departmentLimit.CurrentLimit = departmentLimit.NewLimit;
                                }
                            }
                        }
                    }
                }

                if (updatedCount > 0)
                {
                    MessageBox.Show($"Успешно обновлено лимитов: {updatedCount}", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Перезагружаем данные полностью вместо Refresh
                    LoadDepartmentLimits();
                }
                else
                {
                    MessageBox.Show("Нет изменений для сохранения. Измените значения в столбце 'Новый лимит' и нажмите 'Сохранить все'.", "Информация",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения лимитов: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            // Отменяем редактирование перед обновлением
            LimitsDataGrid.CancelEdit();
            LoadDepartmentLimits();
        }

        private void LimitsDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                if (e.Column.Header.ToString() == "Новый лимит (руб.)")
                {
                    var textBox = e.EditingElement as TextBox;
                    if (textBox != null)
                    {
                        // Разрешаем пустую строку (будет интерпретироваться как 0)
                        if (string.IsNullOrWhiteSpace(textBox.Text))
                        {
                            if (e.Row.DataContext is DepartmentLimit departmentLimit)
                            {
                                departmentLimit.NewLimit = 0;
                            }
                            return;
                        }

                        // Заменяем точку на запятую для корректного парсинга
                        string text = textBox.Text.Replace(".", ",").Trim();

                        // Пробуем разные форматы чисел
                        if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out decimal newValue))
                        {
                            if (newValue < 0)
                            {
                                MessageBox.Show("Лимит не может быть отрицательным", "Ошибка",
                                              MessageBoxButton.OK, MessageBoxImage.Warning);
                                e.Cancel = true;
                            }
                            else
                            {
                                // Форматируем значение для красивого отображения
                                textBox.Text = newValue.ToString("N2");

                                // Немедленно обновляем значение в модели данных
                                if (e.Row.DataContext is DepartmentLimit departmentLimit)
                                {
                                    departmentLimit.NewLimit = newValue;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Введите корректное числовое значение (например: 15000 или 15000,50)", "Ошибка",
                                          MessageBoxButton.OK, MessageBoxImage.Warning);
                            e.Cancel = true;
                        }
                    }
                }
            }
        }

        private void LimitsDataGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            // При начале редактирования убираем форматирование для удобства ввода
            if (e.Column.Header.ToString() == "Новый лимит (руб.)")
            {
                if (e.Row.DataContext is DepartmentLimit departmentLimit)
                {
                    // Устанавливаем простое числовое значение для редактирования
                    var textBox = new TextBox
                    {
                        Text = departmentLimit.NewLimit.ToString("F2"),
                        TextAlignment = TextAlignment.Right
                    };
                }
            }
        }

        private void LimitsDataGrid_PreparingCellForEdit(object sender, DataGridPreparingCellForEditEventArgs e)
        {
            if (e.Column.Header.ToString() == "Новый лимит (руб.)")
            {
                var textBox = e.EditingElement as TextBox;
                if (textBox != null && e.Row.DataContext is DepartmentLimit departmentLimit)
                {
                    textBox.Text = departmentLimit.NewLimit.ToString("F2");
                    textBox.SelectAll();
                }
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // Отменяем редактирование перед выходом
            LimitsDataGrid.CancelEdit();
            Manager.MainFrame.Navigate(new MenuAdmin());
        }
    }

    public class DepartmentLimit : INotifyPropertyChanged
    {
        private decimal _currentLimit;
        private decimal _newLimit;

        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }

        public decimal CurrentLimit
        {
            get => _currentLimit;
            set
            {
                if (_currentLimit != value)
                {
                    _currentLimit = value;
                    OnPropertyChanged(nameof(CurrentLimit));
                }
            }
        }

        public decimal NewLimit
        {
            get => _newLimit;
            set
            {
                if (_newLimit != value)
                {
                    _newLimit = value;
                    OnPropertyChanged(nameof(NewLimit));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}