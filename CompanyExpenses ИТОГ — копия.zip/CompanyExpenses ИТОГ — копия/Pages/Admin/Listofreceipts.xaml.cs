﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace CompanyExpenses.Pages.Admin
{
    public partial class Listofreceipts : Page
    {
        public Listofreceipts()
        {
            InitializeComponent();
            LoadReceipts();
        }

        private void LoadReceipts()
        {
            try
            {
                List<ReceiptInfo> receipts = new List<ReceiptInfo>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            r.receipt_id,
                            r.request_id,
                            e.first_name + ' ' + e.last_name as employee_name,
                            et.name as expense_type_name,
                            pr.amount_planned,
                            r.final_amount,
                            pr.description,
                            r.uploaded_at,
                            r.receipt_image
                        FROM receipts r
                        INNER JOIN paymentrequests pr ON r.request_id = pr.request_id
                        INNER JOIN employees e ON pr.employee_id = e.employee_id
                        INNER JOIN expensetypes et ON pr.expense_type_id = et.type_id
                        ORDER BY r.uploaded_at DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                receipts.Add(new ReceiptInfo
                                {
                                    ReceiptId = reader.GetInt32(0),
                                    RequestId = reader.GetInt32(1),
                                    EmployeeName = reader.GetString(2),
                                    ExpenseTypeName = reader.GetString(3),
                                    AmountPlanned = reader.GetDecimal(4),
                                    FinalAmount = reader.GetDecimal(5),
                                    Description = reader.IsDBNull(6) ? string.Empty : reader.GetString(6),
                                    UploadedAt = reader.GetDateTime(7),
                                    ReceiptImagePath = reader.IsDBNull(8) ? null : reader.GetString(8)
                                });
                            }
                        }
                    }
                }

                ReceiptsGrid.ItemsSource = receipts;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки чеков: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ViewReceiptButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is ReceiptInfo receipt)
            {
                if (string.IsNullOrEmpty(receipt.ReceiptImagePath))
                {
                    MessageBox.Show("Файл чека не найден.", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                try
                {
                    string fullPath = Path.Combine(Directory.GetCurrentDirectory(), receipt.ReceiptImagePath);

                    if (File.Exists(fullPath))
                    {
                        // Открытие файла с помощью ассоциированной программы
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = fullPath,
                            UseShellExecute = true
                        });
                    }
                    else
                    {
                        MessageBox.Show("Файл чека не найден по пути: " + fullPath, "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии чека: {ex.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadReceipts();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }
    }

    public class ReceiptInfo
    {
        public int ReceiptId { get; set; }
        public int RequestId { get; set; }
        public string EmployeeName { get; set; }
        public string ExpenseTypeName { get; set; }
        public decimal AmountPlanned { get; set; }
        public decimal FinalAmount { get; set; }
        public string Description { get; set; }
        public DateTime UploadedAt { get; set; }
        public string ReceiptImagePath { get; set; }
    }
}