﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CompanyExpenses.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для Referencebooks.xaml
    /// </summary>
    public partial class Referencebooks : Page
    {
        public Referencebooks()
        {
            InitializeComponent();
        }

        private void EditDepartments_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new DepartmentsPage());
        }

        private void EditEmployees_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new EmployeePage());
        }

        private void Edittypesofexpenses_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TypesofexpensesPage());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new MenuAdmin());
        }

    }
}
