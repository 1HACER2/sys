﻿using CompanyExpenses.Pages.Edit;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages.Admin
{
    public partial class TypesofexpensesPage : Page
    {
        public TypesofexpensesPage()
        {
            InitializeComponent();
            LoadExpenseTypes();
        }

        private void LoadExpenseTypes()
        {
            try
            {
                List<ExpenseType> expenseTypes = new List<ExpenseType>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            name
                        FROM expensetypes 
                        ORDER BY name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            expenseTypes.Add(new ExpenseType
                            {
                                Name = reader.GetString(0)
                            });
                        }
                    }
                }

                ExpenseTypesGrid.ItemsSource = expenseTypes;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadExpenseTypes();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TypesofexpensesPageEdit());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Referencebooks());
        }
    }

    public class ExpenseType
    {
        public string Name { get; set; }
    }
}