﻿using CompanyExpenses.Pages.Edit;
using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages
{
    public partial class Lk : Page
    {
        public Lk()
        {
            InitializeComponent();
            LoadUserData();
        }

        private void LoadUserData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            e.employee_id,
                            e.email,
                            e.first_name,
                            e.last_name,
                            d.name as department_name,
                            CASE 
                                WHEN e.ID_Role = 1 THEN 'Администратор'
                                WHEN e.ID_Role = 2 THEN 'Сотрудник'
                                ELSE 'Неизвестно'
                            END as role_name
                        FROM employees e
                        LEFT JOIN departments d ON e.department_id = d.department_id
                        WHERE e.employee_id = @EmployeeId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmployeeId", CurrentUser.EmployeeId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Заполняем данные
                                FullNameText.Text = $"{reader.GetString(2)} {reader.GetString(3)}";
                                EmailText.Text = reader.GetString(1);
                                DepartmentText.Text = reader.IsDBNull(4) ? "Не указан" : reader.GetString(4);
                                RoleText.Text = reader.GetString(5);
                                EmployeeIdText.Text = reader.GetInt32(0).ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Red_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new LkEdit());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.NavigationService.GoBack();
        }
    }
}