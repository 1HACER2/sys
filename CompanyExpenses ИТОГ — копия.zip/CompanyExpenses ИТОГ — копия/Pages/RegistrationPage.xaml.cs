﻿using CompanyExpenses.Pages.Edit;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages
{
    public partial class RegistrationPage : Page
    {
        public RegistrationPage()
        {
            InitializeComponent();
            LoadDepartments();
            LoadRoles();
        }

        private void LoadDepartments()
        {
            try
            {
                List<Department> departments = new List<Department>();

                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT department_id, name FROM departments ORDER BY name";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            departments.Add(new Department
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1)
                            });
                        }
                    }
                }

                DepartmentComboBox.ItemsSource = departments;
                DepartmentComboBox.DisplayMemberPath = "Name";
                DepartmentComboBox.SelectedValuePath = "Id";
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки отделов: {ex.Message}");
            }
        }

        private void LoadRoles()
        {
            try
            {
                var roles = new List<Role>
                {
                    new Role { Id = 1, Name = "Администратор" },
                    new Role { Id = 2, Name = "Сотрудник" }
                };

                RoleComboBox.ItemsSource = roles;
                RoleComboBox.DisplayMemberPath = "Name";
                RoleComboBox.SelectedValuePath = "Id";
                RoleComboBox.SelectedIndex = 1; // По умолчанию "Сотрудник"
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка загрузки ролей: {ex.Message}");
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password;
            string firstName = FirstNameTextBox.Text.Trim();
            string lastName = LastNameTextBox.Text.Trim();

            if (DepartmentComboBox.SelectedItem == null)
            {
                ShowError("Выберите отдел");
                return;
            }

            if (RoleComboBox.SelectedItem == null)
            {
                ShowError("Выберите роль");
                return;
            }

            int departmentId = (int)DepartmentComboBox.SelectedValue;
            int roleId = (int)RoleComboBox.SelectedValue;

            // Валидация
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                ShowError("Заполните все поля");
                return;
            }

            if (!IsValidEmail(email))
            {
                ShowError("Введите корректный email");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    // Проверяем нет ли уже такого email
                    string checkQuery = "SELECT COUNT(*) FROM employees WHERE email = @Email";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Email", email);
                        int count = (int)checkCommand.ExecuteScalar();

                        if (count > 0)
                        {
                            ShowError("Пользователь с таким email уже существует");
                            return;
                        }
                    }

                    // Добавляем нового пользователя
                    string insertQuery = @"
                        INSERT INTO employees (email, password, first_name, last_name, department_id, ID_Role)
                        VALUES (@Email, @Password, @FirstName, @LastName, @DepartmentId, @RoleId)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@DepartmentId", departmentId);
                        command.Parameters.AddWithValue("@RoleId", roleId);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Пользователь успешно зарегистрирован!", "Успех",
                                          MessageBoxButton.OK, MessageBoxImage.Information);
                            ClearForm();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка регистрации: {ex.Message}");
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void ClearForm()
        {
            EmailTextBox.Text = "";
            PasswordBox.Password = "";
            FirstNameTextBox.Text = "";
            LastNameTextBox.Text = "";
            DepartmentComboBox.SelectedIndex = -1;
            RoleComboBox.SelectedIndex = 1;
            HideError();
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
        }

        private void HideError()
        {
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new MainMenu());
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new MainMenu());
        }
    }

    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Role
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}