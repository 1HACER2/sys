﻿using CompanyExpenses.Pages.Admin;
using CompanyExpenses.Pages.User;
using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace CompanyExpenses.Pages
{
    public partial class AuthorizationPage : Page
    {
        public AuthorizationPage()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(Manager.ConnectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT e.employee_id, e.first_name, e.last_name, e.ID_Role 
                        FROM employees e 
                        WHERE e.email = @Email AND e.password = @Password";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", login);
                        command.Parameters.AddWithValue("@Password", password);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int employeeId = reader.GetInt32(0);
                                string firstName = reader.GetString(1);
                                string lastName = reader.GetString(2);
                                int roleId = reader.GetInt32(3);

                                CurrentUser.EmployeeId = employeeId;
                                CurrentUser.FirstName = firstName;
                                CurrentUser.LastName = lastName;
                                CurrentUser.RoleId = roleId;

                                RedirectByRole(roleId);
                            }
                            else
                            {
                                ShowError("Неверный логин или пароль");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка авторизации: {ex.Message}");
            }
        }

        private void RedirectByRole(int roleId)
        {
            switch (roleId)
            {
                case 1: // Администратор
                    Manager.MainFrame.Navigate(new MenuAdmin());
                    break;
                case 2: // Сотрудник
                    Manager.MainFrame.Navigate(new MenuUser());
                    break;
                default:
                    ShowError($"Неизвестная роль: {roleId}");
                    break;
            }
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
        }

        private void HideError()
        {
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new MainMenu());
        }

        private void vrem_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new MenuAdmin());
        }

        private void LoginTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            HideError();
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            HideError();
        }
    }

    public static class CurrentUser
    {
        public static int EmployeeId { get; set; }
        public static string FirstName { get; set; }
        public static string LastName { get; set; }
        public static int RoleId { get; set; }
        public static string FullName => $"{FirstName} {LastName}";
        public static bool IsAdmin => RoleId == 1;
    }
}